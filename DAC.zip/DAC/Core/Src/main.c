/* USER CODE BEGIN Header */
/**
******************************************************************************
* @file           : main.c
* @brief          : Main program body
******************************************************************************
* @attention
*
* Copyright (c) 2023 STMicroelectronics.
* All rights reserved.
*
* This software is licensed under terms that can be found in the LICENSE file
* in the root directory of this software component.
* If no LICENSE file comes with this software, it is provided AS-IS.
*
******************************************************************************
*/
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "dac.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "math.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
int dac_mode = 0;    //�����л�����ģʽ
int dy_10=0,pl_100=0,pl;   //���ε�ѹ ����Ƶ��
int dy=0;
int A, B, C;
char *Mode[5]={"ֱ����ѹ","����","���ǲ�","���Ҳ�","MC��"};

uint32_t output_voltage = (uint32_t)(3.0 / 3.3 * 4096);  //�����ѹ���ֵ

uint16_t Sin[32]={2048	, 2460	, 2856	, 3218	, 3532	, 3786	, 3969	, 4072	,
	4093	, 4031	, 3887	, 3668	, 3382	, 3042	,2661	, 2255	, 
	1841	, 1435	, 1054	, 714	, 428	, 209	, 65	, 3		,
	24		, 127	, 310	, 564	, 878	, 1240	, 1636	, 2048};
uint16_t Triangle[300]={0,59,118,176,235,294,353,411,470,
		529,588,647,705,764,823,882,941,999,1058,1117,1176,1234,
		1293,1352,1411,1470,1528,1587,1646,1705,1763,1822,1881,1940,
		1999,2057,2116,2175,2234,2292,2351,2410,2469,2528,2586,2645,
		2704,2763,2822,2880,2939,2998,3057,3115,3174,3233,3292,3351,
		3409,3468,3527,3586,3644,3703,3762,3703,3644,3586,3527,3468,
		3409,3351,3292,3233,3174,3115,3057,2998,2939,2880,2822,2763,
		2704,2645,2586,2528,2469,2410,2351,2292,2234,2175,2116,2057,
		1999,1940,1881,1822,1763,1705,1646,1587,1528,1470,1411,1352,
		1293,1234,1176,1117,1058,999,941,882,823,764,705,647,588,529,
		470,411,353,294,235,176,118,59,};
uint16_t Square[300]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0
		,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,3718,3718
		,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718
		,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718
		,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718
		,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718,3718};

uint16_t MC[300]={2482,2432,2383,2333,2283,2234,2184,2134,2085,2035,1985,1936,
		1886,1837,1787,1737,1688,1638,1588,1539,1489,1439,1390,1340,1291,1241,1191,1142,1092,
		1042,993,943,893,844,794,745,695,645,596,546,496,447,397,347,298,248,199,149,99,50,50,
		99,149,199,248,298,347,397,447,496,546,596,645,695,745,794,844,893,943,993,1042,1092,
		1142,1191,1241,1291,1340,1390,1439,1489,1539,1588,1638,1688,1737,1787,1837,1886,1936,
		1985,2035,2085,2134,2184,2234,2283,2333,2383,2432,2482,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,
		0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,78,156,234,311,
		388,465,541,617,692,767,841,914,986,1057,1127,1196,1263,1330,1395,1459,1521,1582,1641
		,1699,1755,1809,1862,1912,1961,2008,2053,2096,2136,2175,2211,2246,2278,2308,2335,2361,
		2383,2404,2422,2438,2451,2462,2471,2477,2481,2482,2482,2457,2432,2407,2383,2358,2333,
		2308,2283,2258,2234,2209,2184,2159,2134,2110,2085,2060,2035,2010,1985,1961,1936,1911,
		1886,1861,1837,1812,1787,1762,1737,1712,1688,1663,1638,1613,1588,1564,1539,1514,1489,
		1464,1439,1415,1390,1365,1340,1315,1291,1266,1241,1216,1191,1166,1142,1117,1092,1067,
		1042,1018,993,968,943,918,893,869,844,819,794,769,745,720,695,670,645,620,596,571,546,
		521,496,472,447,422,397,372,347,323,298,273,248,223,199,174,149,124,99,74,50,25,};
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void finds(int A, int *B, int *C);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_DAC_Init();
  MX_TIM2_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
	printf("Hello World\r\n\r\n");
	HAL_TIM_Base_Start(&htim2);
	printf("ģʽ��%s  Ƶ�ʣ�200Hz   Vpp��0.0V\r\n\r\n\r\n\r\n",Mode[0]);  //����������

	HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1,DAC_ALIGN_12B_R,0);
	HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
while (1)
{
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */

}
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSI;
  RCC_OscInitStruct.HSIState = RCC_HSI_ON;
  RCC_OscInitStruct.HSICalibrationValue = RCC_HSICALIBRATION_DEFAULT;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSI;
  RCC_OscInitStruct.PLL.PLLM = 8;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */


/***** �����ж� *****/
void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)
{
	UNUSED(GPIO_Pin);
	if(GPIO_Pin == GPIO_PIN_0){  //�����л����Σ�0~4����
		HAL_Delay(20);
		if(GPIO_Pin == GPIO_PIN_0){
			dac_mode=(dac_mode+1)%5;
			switch(dac_mode){
				case 0: //ֱ����ѹ
				dy_10=0;
				pl_100=2;
				HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
				//HAL_DAC_Stop(&hdac, DAC_CHANNEL_1);
				HAL_Delay(3);
				HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1,DAC_ALIGN_12B_R,dy);
				HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
				break;
				case 1:  //����
				pl_100=10;
				dy_10=30;
				finds(65625/pl_100/10,&B,&C);
				HAL_DAC_Stop(&hdac, DAC_CHANNEL_1);
				HAL_Delay(3);
				HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)&Square, 128, DAC_ALIGN_12B_R);break;
				case 2:  //���ǲ�
				pl_100=50;
				finds(65625/pl_100/10,&B,&C);
				dy_10=30;
				HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
				HAL_Delay(3);
				HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)&Triangle, 128, DAC_ALIGN_12B_R);break;
				case 3:  //���Ҳ�
				pl_100=250;
				finds(262500/pl_100/10,&B,&C);
				dy_10=30;
				HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
				HAL_Delay(3);
				HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)&Sin, 32, DAC_ALIGN_12B_R);break;
				case 4:  //MC��
				pl_100=2;
				TIM2->ARR=100-1;
				TIM2->PSC=36-1;
				dy_10=20;
				HAL_DAC_Stop_DMA(&hdac, DAC_CHANNEL_1);
				HAL_Delay(3);
				HAL_DAC_Start_DMA(&hdac, DAC_CHANNEL_1, (uint32_t*)&MC, 300, DAC_ALIGN_12B_R);
				break;
				default:break;
			}
		}
	}

	if(GPIO_Pin == GPIO_PIN_8){  //�����л���ѹ
		HAL_Delay(20);
		if(GPIO_Pin == GPIO_PIN_8){
			if(dy_10 > 30) dy_10=0;
			else dy_10=dy_10+1;
		dy=dy_10*4096/33+20;
		//HAL_DAC_Stop(&hdac, DAC_CHANNEL_1);
		HAL_DAC_SetValue(&hdac, DAC_CHANNEL_1,DAC_ALIGN_12B_R,dy);
		HAL_DAC_Start(&hdac, DAC_CHANNEL_1);
		}
	}

	if(GPIO_Pin == GPIO_PIN_9){  //�����л�Ƶ��
		HAL_Delay(20);
		if(GPIO_Pin == GPIO_PIN_9){
			switch(dac_mode){
				case 1: pl_100 = (pl_100>=100)?10:pl_100+10;finds(65625/pl_100/10,&B,&C);break;
				case 2: pl_100 = (pl_100>=100)?50:pl_100+10;finds(65625/pl_100/10,&B,&C);break;
				case 3: pl_100 = (pl_100>=500)?250:pl_100+50;finds(262500/pl_100/10,&B,&C);break;
				default: pl_100 = 2;break;
			}
		}
	}
	printf("ģʽ��%s  Ƶ�ʣ�%dHz   Vpp��%.1fV\r\n\r\n\r\n\r\n",Mode[dac_mode],pl_100*100,(double)dy_10/10);  //����������
}


void finds(int A, int *B, int *C) {  //�˺������㵱Ƶ�ʸ���ʱPSC��ARR�˻�Ϊ��ֵʱ��ӽ�pl
	int sqrtA = sqrt(A),ii;
	/*if (sqrtA > 65535)
		sqrtA = 65535;*/
	//int minDiff = A;
	for (ii = sqrtA; ii > 0; ii--) {
		if (A % ii == 0) {
			int j = A / ii;
			if (j <= 65535) {
				*B = ii;
				*C = j;
				break;
			}
		}
	}
	TIM2->ARR=*C-1;
	TIM2->PSC=*B-1;
}

#if 1
#pragma import(__use_no_semihosting)         
struct __FILE { 
int handle; 
}; 
FILE __stdout;       
void _sys_exit(int x) { 
x = x; 
} 
int fputc(int ch, FILE *f){     
while((USART1->SR&0X40)==0);
USART1->DR = (uint8_t) ch;      
return ch;
}
#endif
/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
/* User can add his own implementation to report the HAL error return state */
__disable_irq();
while (1)
{
}
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
/* User can add his own implementation to report the file name and line number,
 ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
