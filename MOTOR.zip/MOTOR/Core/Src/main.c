/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2023 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"
#include "fsmc.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include "stdio.h"
#include "stdlib.h"
#include "string.h"
#include "lcd.h"
#include "touch.h"
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */
#define RXBUFFERSIZE  256
/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define PPR 500
#define RR 20
#define ARR 10000
//#define Proportion	0.45;
//#define Integral	0.1;
//#define Derivative	0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
char RxBuffer[RXBUFFERSIZE],rx[6];
uint8_t aRxBuffer;
uint8_t Uart1_Rx_Cnt = 0;

int flag_pwm=1;
int Cnt=5000;

int MotorSpeed;
int Encode=0;
int SetSpeed=100;  //�趨�ٶ�
int Acc=0; 		   //���ٶ�
int Bias=0;

static double   Proportion=1.35;
static double   Integral=1.2;
static double   Derivative=0.1;

char dis[10];
int n=0;
/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
void Generate(void);
void input(void);
int PID(int current,int target);
/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_FSMC_Init();
  MX_TIM6_Init();
  MX_TIM2_Init();
  MX_TIM14_Init();
  MX_TIM3_Init();
  MX_USART1_UART_Init();
  /* USER CODE BEGIN 2 */
    HAL_TIM_Encoder_Start(&htim3, TIM_CHANNEL_ALL);
	HAL_TIM_Base_Start_IT(&htim3);
	HAL_TIM_Base_Start_IT(&htim2);
	HAL_TIM_PWM_Start(&htim14,TIM_CHANNEL_1);

//	printf("Hello World!\r\n\r\n");
	LCD_Init();           			//��ʼ��LCD FSMC�ӿ�
	POINT_COLOR=RED;     			//������ɫ����ɫ
	LCD_Clear(WHITE);
	tp_dev.init();
	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer, 1);
	HAL_Delay(300);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
	  tp_dev.scan (0);
	  input();
	  Generate();
	  MotorSpeed=(Encode*60*100)/(PPR*RR*4);    //speed = Encode * 0.15
	  LCD_ShowNum(150,200,MotorSpeed,8,32);
	  LCD_ShowNum(150,300,Cnt/100,6,32);
	  LCD_ShowNum(150,400,SetSpeed,6,32);
	  printf("%d,%d\n",MotorSpeed,SetSpeed);

    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  __HAL_RCC_PWR_CLK_ENABLE();
  __HAL_PWR_VOLTAGESCALING_CONFIG(PWR_REGULATOR_VOLTAGE_SCALE1);

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = 4;
  RCC_OscInitStruct.PLL.PLLN = 168;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = 4;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV4;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV2;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_5) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
int PID(int current,int target)  //PID�ٶȿ���
{
	static int      LastError;				//Error[-1]
	static int      PrevError; 			    //Error[-2]
	int iError,Outpid;						//��ǰ���
	target=target/0.15;						//���ٶ�ֵת��Ϊ����ֵ

	iError=target-current;		 			//��������
	Outpid=(Proportion * iError)  			//E[k]��
			  -(Integral * LastError) 		//E[k-1]��
			  +(Derivative * PrevError);	//E[k-2]��

	PrevError=LastError; 					//�洢�������´μ���
	LastError=iError;
	return Outpid;
}


void HAL_TIM_PeriodElapsedCallback(TIM_HandleTypeDef *htim)  //����������
{
  UNUSED(htim);
	if(htim->Instance==TIM2){
		Encode = (short)(__HAL_TIM_GET_COUNTER(&htim3));
		__HAL_TIM_SET_COUNTER(&htim3,0);
		Bias=PID(Encode,SetSpeed);
	}
}



void Generate(void)  //����Cnt��
{
	if(flag_pwm){  //Cnt������
		if(Bias<-3||Bias>3)
			Cnt+=Bias;
		Cnt=(Cnt>9992)?9992:Cnt;
		TIM14->CCR1=Cnt;
	}
}



void input(void)  //��������
{
	if(tp_dev.sta&TP_PRES_DOWN){
		if(tp_dev.x[0]<500&&tp_dev.y[0]<240&&tp_dev.y[0]>=120&&tp_dev.x[0]>=400){
			HAL_Delay(80);
			if(tp_dev.x[0]<500&&tp_dev.y[0]<240&&tp_dev.y[0]>=120&&tp_dev.x[0]>=400) dis[n]='7';
		}
		else if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<240&&tp_dev.y[0]>=120){
			HAL_Delay(80);
			if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<240&&tp_dev.y[0]>=120) dis[n]='8';
		}
		else if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<240&&tp_dev.y[0]>=120){
			HAL_Delay(80);
			if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<240&&tp_dev.y[0]>=120) dis[n]='9';
		}
		else if(tp_dev.x[0]<500&&tp_dev.x[0]>=400&&tp_dev.y[0]<360&&tp_dev.y[0]>=240){
			HAL_Delay(80);
			if(tp_dev.x[0]<500&&tp_dev.x[0]>=400&&tp_dev.y[0]<360&&tp_dev.y[0]>=240) dis[n]='4';
		}
		else if(tp_dev.x[0]<500&&tp_dev.x[0]>=400&&tp_dev.y[0]<480&&tp_dev.y[0]>=360){
			HAL_Delay(80);
			if(tp_dev.x[0]<500&&tp_dev.x[0]>=400&&tp_dev.y[0]<480&&tp_dev.y[0]>=360) dis[n]='1';
		}
		else if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<360&&tp_dev.y[0]>=240){
			HAL_Delay(80);
			if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<360&&tp_dev.y[0]>=240) dis[n]='5';
		}
		else if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<480&&tp_dev.y[0]>=360){
			HAL_Delay(80);
			if(tp_dev.x[0]>=500&&tp_dev.x[0]<600&&tp_dev.y[0]<480&&tp_dev.y[0]>=360) dis[n]='2';
		}
		else if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<360&&tp_dev.y[0]>=240){
			HAL_Delay(80);
			if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<360&&tp_dev.y[0]>=240) dis[n]='6';
		}
		else if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<480&&tp_dev.y[0]>=360){
			HAL_Delay(80);
			if(tp_dev.x[0]>=600&&tp_dev.x[0]<700&&tp_dev.y[0]<480&&tp_dev.y[0]>=360) dis[n]='3';
		}
		else if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<360&&tp_dev.y[0]>=240){
			HAL_Delay(80);
			if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<360&&tp_dev.y[0]>=240) dis[n]='0';
		}
		else if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<240&&tp_dev.y[0]>=120){
			HAL_Delay(80);
			if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<240&&tp_dev.y[0]>=120){//�˸�
				dis[n-1]=' ';
				n=n-2;
			}
		}
		else if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<120&&tp_dev.y[0]>=0){
			HAL_Delay(80);
			if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<120&&tp_dev.y[0]>=0){ //����
				memset(dis,'\0',sizeof(dis));
				LCD_Clear(WHITE);
				n=-1;
			}
		}
		else if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<480&&tp_dev.y[0]>=360){//ȷ������
			HAL_Delay(90);
			if(tp_dev.x[0]>=700&&tp_dev.x[0]<800&&tp_dev.y[0]<480&&tp_dev.y[0]>=360){
				dis[n]='\0';
				int sp=(atoi(dis)>500||atoi(dis)<1)?310:atoi(dis);
				SetSpeed=abs((sp>310)?310:sp);
				memset(dis,'\0',sizeof(dis));
				n=-1;
			}
		}
		n++;
		LCD_ShowString(500,80,200,20,32,dis);
	}
}


void HAL_GPIO_EXTI_Callback(uint16_t GPIO_Pin)  //�����ж�
{
	UNUSED(GPIO_Pin);
	if(GPIO_Pin==KEY0_Pin)
	{
		HAL_Delay(20);
		if(GPIO_Pin==KEY0_Pin)
		{
			HAL_GPIO_TogglePin(GPIOF,GPIO_PIN_9);
			HAL_UART_Transmit(&huart1, (uint8_t *)"hello1\r\n", 10,0xFFFF);
			printf("hello\r\n");
		}
	}
	if(GPIO_Pin==KEY1_Pin)
	{
		HAL_Delay(20);
		if(GPIO_Pin==KEY1_Pin)
		{
			flag_pwm=1-flag_pwm;
		}
	}
}


//void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)  //����ͨ��
//{
//  UNUSED(huart);
//	if(Uart1_Rx_Cnt >= 255){
//		Uart1_Rx_Cnt = 0;
//		memset(RxBuffer,0x00,sizeof(RxBuffer));
//		HAL_UART_Transmit(&huart1, (uint8_t *)"OUT OF RANGE", 10,0xFFFF);
//	}
//	else{
//		RxBuffer[Uart1_Rx_Cnt++] = aRxBuffer;
//		if((RxBuffer[Uart1_Rx_Cnt-1] == 0x0A)&&(RxBuffer[Uart1_Rx_Cnt-2] == 0x0D)){
//			strcpy(rx,RxBuffer);
//			SetSpeed=atoi(rx);
////			printf("Cnt=%d\r\n",Cnt);
//            while(HAL_UART_GetState(&huart1) == HAL_UART_STATE_BUSY_TX);
//			Uart1_Rx_Cnt = 0;
//			memset(RxBuffer,0x00,sizeof(RxBuffer));
//		}
//	}
//	HAL_UART_Receive_IT(&huart1, (uint8_t *)&aRxBuffer, 1);
//}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
