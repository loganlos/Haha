#ifndef CPROJECT_TIMX_DELAY_H
#define CPROJECT_TIMX_DELAY_H
#include "tim.h"

#define DEL_TIM_Handle &htim6

void delay_us(uint16_t us);

#endif
