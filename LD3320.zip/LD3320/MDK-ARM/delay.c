#include "delay.h"

//��ʱn_ms
void delay_ms(volatile unsigned long nms)
{
	HAL_Delay(nms);
}
//��ʱnus
void delay_us(volatile unsigned long nus)
{
	__IO uint32_t currentTicks = SysTick->VAL;
	/* Number of ticks per millisecond */
	const uint32_t tickPerMs = SysTick->LOAD + 1;
	/* Number of ticks to count */
	const uint32_t nbTicks = ((nus - ((nus > 0) ? 1 : 0)) * tickPerMs) / 1000;
	/* Number of elapsed ticks */
	uint32_t elapsedTicks = 0;
	__IO uint32_t oldTicks = currentTicks;
	do {
		currentTicks = SysTick->VAL;
		elapsedTicks += (oldTicks < currentTicks) ? tickPerMs + oldTicks - currentTicks :
		oldTicks - currentTicks;
		oldTicks = currentTicks;
	} while (nbTicks > elapsedTicks);
}
 
//���ж��н�time_delay�ݼ���ʵ����ʱ

