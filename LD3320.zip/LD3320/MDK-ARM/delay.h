#ifndef DELAY_H__
#define DELAY_H__

#include "main.h"

void delay_us(volatile unsigned long nus);

void delay_ms(volatile unsigned long nms);

#endif
